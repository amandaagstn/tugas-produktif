﻿Public Class Form1
    Dim sqlnya As String
    Sub panggildata()
        konek()
        DA = New OleDb.OleDbDataAdapter("SELECT * FROM list", conn)
        DS = New DataSet
        DS.Clear()
        DA.Fill(DS, "list")
        DataGridView1.DataSource = DS.Tables("list")
        DataGridView1.Enabled = True
    End Sub
    Sub jalan()
        Dim objcmd As New System.Data.OleDb.OleDbCommand
        Call konek()
        objcmd.Connection = conn
        objcmd.CommandType = CommandType.Text
        objcmd.CommandText = sqlnya
        objcmd.ExecuteNonQuery()
        objcmd.Dispose()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call konek()
        Call panggildata()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        sqlnya = "insert into list (Nama, Rombel, Rayon) values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "')"
        Call jalan()
        MsgBox("Data berhasil tersimpan")
        Call panggildata()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        TextBox1.Text = DataGridView1.Item(0, i).Value
        TextBox2.Text = DataGridView1.Item(1, i).Value
        TextBox3.Text = DataGridView1.Item(2, i).Value
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        sqlnya = "UPDATE list set Rombel = '" & TextBox2.Text & "',Rayon='" & TextBox3.Text & "' where Nama='" & TextBox1.Text & "'"
        Call jalan()
        MsgBox("Data berhasil terubah")
        Call panggildata()
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        konek()
        DA = New OleDb.OleDbDataAdapter("SELECT * FROM list where Rombel like '%" & TextBox5.Text & "%'", conn)
        DS = New DataSet
        DS.Clear()
        DA.Fill(DS, "list")
        DataGridView1.DataSource = DS.Tables("list")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        sqlnya = "delete from list where Nama='" & TextBox1.Text & "'"
        Call jalan()
        MsgBox("Data berhasil terhapus")
        Call panggildata()
    End Sub
    'ini buat ngitung checkbox
    Dim skor As Integer

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged
        If CheckBox4.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox5.CheckedChanged
        If CheckBox5.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox6.CheckedChanged
        If CheckBox6.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox7_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox7.CheckedChanged
        If CheckBox7.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox8_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox8.CheckedChanged
        If CheckBox8.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox9_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox9.CheckedChanged
        If CheckBox9.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox10_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox10.CheckedChanged
        If CheckBox10.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox11_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox11.CheckedChanged
        If CheckBox11.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox12_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox12.CheckedChanged
        If CheckBox12.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox13_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox13.CheckedChanged
        If CheckBox13.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox14_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox14.CheckedChanged
        If CheckBox14.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox15_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox15.CheckedChanged
        If CheckBox15.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox16_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox16.CheckedChanged
        If CheckBox16.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox17_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox17.CheckedChanged
        If CheckBox17.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox18_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox18.CheckedChanged
        If CheckBox18.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox19_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox19.CheckedChanged
        If CheckBox19.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox20_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox20.CheckedChanged
        If CheckBox20.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub

    Private Sub CheckBox21_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox21.CheckedChanged
        If CheckBox21.Checked = True Then
            skor += 1
            Label1.Text = skor
        Else
            skor -= 1
            Label1.Text = skor
        End If
    End Sub
End Class

